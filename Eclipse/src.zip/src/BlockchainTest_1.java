import static org.junit.Assert.*;
import org.junit.Test;

public class BlockchainTest_1 {
	
	@Test
	public void test_invalid_transactions() {
		Blockchain block = new Blockchain();
		assertEquals(0, block.addTransaction("aaa"));
	}
	
	@Test
	public void test_more_invalid() {
		Blockchain block = new Blockchain();
		assertEquals(0, block.addTransaction("tx|test000a|2"));
		assertEquals(0, block.addTransaction("tx|0est0000|7"));
		assertEquals(0, block.addTransaction("ff|test0000|7"));
	}
	
	@Test
	public void test_blockchain_length() {
		Blockchain block = new Blockchain();
		assertEquals(1, block.addTransaction("tx|test0000|7"));
		assertEquals(1, block.addTransaction("tx|test0000|7"));
		assertEquals(2, block.addTransaction("tx|test0000|7"));
	}

}
